const express=require('express');const session=require('express-session');const Database=require('better-sqlite3');const bcrypt=require('bcryptjs');const path=require('path');
const app=express();const db=new Database('results.db');
app.use(express.json());app.use(express.urlencoded({extended:true}));app.use(session({secret:process.env.SESSION_SECRET||'change-this-secret',resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:'lax'}}));
app.use(express.static(path.join(__dirname,'public')));
db.exec(`CREATE TABLE IF NOT EXISTS admin(id INTEGER PRIMARY KEY,username TEXT UNIQUE,password_hash TEXT);CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY AUTOINCREMENT,roll TEXT UNIQUE NOT NULL,name TEXT NOT NULL,physics REAL DEFAULT 0,chemistry REAL DEFAULT 0,math REAL DEFAULT 0,english REAL DEFAULT 0,hindi REAL DEFAULT 0,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);`);
if(!db.prepare('SELECT 1 FROM admin LIMIT 1').get()) db.prepare('INSERT INTO admin(username,password_hash) VALUES(?,?)').run('admin',bcrypt.hashSync('admin123',10));
function auth(req,res,next){if(req.session.admin)return next();res.status(401).json({error:'Unauthorized'});}
app.get('/api/result/:roll',(req,res)=>{const s=db.prepare('SELECT * FROM students WHERE roll=?').get(req.params.roll.trim());if(!s)return res.status(404).json({error:'Result not found'});const total=s.physics+s.chemistry+s.math+s.english+s.hindi;const percentage=total/5;res.json({...s,total,percentage:percentage.toFixed(2),status:percentage>=33?'PASS':'FAIL'});});
app.post('/api/login',(req,res)=>{const a=db.prepare('SELECT * FROM admin WHERE username=?').get(req.body.username);if(!a||!bcrypt.compareSync(req.body.password,a.password_hash))return res.status(401).json({error:'Invalid ID or password'});req.session.admin={id:a.id,username:a.username};res.json({ok:true});});
app.post('/api/logout',auth,(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/me',(req,res)=>res.json({admin:req.session.admin||null}));
app.get('/api/students',auth,(req,res)=>res.json(db.prepare('SELECT * FROM students ORDER BY roll').all()));
app.post('/api/students',auth,(req,res)=>{try{const x=req.body;const st=db.prepare(`INSERT INTO students(roll,name,physics,chemistry,math,english,hindi) VALUES(?,?,?,?,?,?,?)`).run(x.roll,x.name,+x.physics||0,+x.chemistry||0,+x.math||0,+x.english||0,+x.hindi||0);res.json({ok:true,id:st.lastInsertRowid});}catch(e){res.status(400).json({error:e.message.includes('UNIQUE')?'Roll number already exists':e.message});}});
app.put('/api/students/:id',auth,(req,res)=>{const x=req.body;db.prepare(`UPDATE students SET roll=?,name=?,physics=?,chemistry=?,math=?,english=?,hindi=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(x.roll,x.name,+x.physics||0,+x.chemistry||0,+x.math||0,+x.english||0,+x.hindi||0,req.params.id);res.json({ok:true});});
app.delete('/api/students/:id',auth,(req,res)=>{db.prepare('DELETE FROM students WHERE id=?').run(req.params.id);res.json({ok:true});});
app.post('/api/change-password',auth,(req,res)=>{if(!req.body.password||req.body.password.length<6)return res.status(400).json({error:'Password must be at least 6 characters'});db.prepare('UPDATE admin SET password_hash=? WHERE id=?').run(bcrypt.hashSync(req.body.password,10),req.session.admin.id);res.json({ok:true});});
app.listen(process.env.PORT||3000,()=>console.log('ELPC Results Portal running'));
