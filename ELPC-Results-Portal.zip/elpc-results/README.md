# ELPC Student Results Portal

A real Node.js + Express + SQLite result portal with a protected admin dashboard.

## Run locally
1. Install Node.js 18+.
2. In this folder run `npm install`.
3. Set a strong `SESSION_SECRET` environment variable.
4. Run `npm start`.
5. Open `http://localhost:3000`.

Default admin: `admin` / `admin123` — change it immediately from the dashboard.

## Production
Deploy this project to a Node.js host that supports persistent SQLite storage (or replace SQLite with a managed database). Set `SESSION_SECRET` and `PORT` in the hosting environment. Use HTTPS.
